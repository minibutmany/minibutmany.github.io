package com.joec.ld29;

public class BossBacteria extends Cell
{
	boolean spawned = false;
	int health = 175;
	
	public BossBacteria(int size) 
	{
		super(128);
		shape.positionX = -256;
		MAX_SPEED = 60;
		ACCEL = 40;
		SLOW = 50;
	}
	
	public void update(float delta, float x, float y)
	{
		if(spawned && alive)
		{
			if(x > shape.positionX)
				moveRight(delta);
			if(x < shape.positionX)
				moveLeft(delta);
			if(y > shape.positionY)
				moveUp(delta);
			if(y < shape.positionY)
				moveDown(delta);
			super.update(delta);
		}
	}
	
	public boolean killOnCollisionWith(CollisionShape objShape) 
	{
		if(shape.rectanglesColliding(objShape))
		{
			health -= (int)(Math.random() * 5);
			if(health <= 0)
				alive = false;
			return true;
		}
		else
			return false;
	}
	
	@Override
	public void moveLeft(float delta)
	{
		if(leftSpeed <= MAX_SPEED)
		{
			leftSpeed += ACCEL * delta;
			rightSpeed -= SLOW * 4 * delta;
		}
		rotate(1);
	}
	@Override
	public void moveRight(float delta)
	{
		if(rightSpeed <= MAX_SPEED)
		{
			rightSpeed += ACCEL * delta;
			leftSpeed -= SLOW * 4 * delta;
		}
		rotate(-1);
	}
	@Override
	public void moveUp(float delta)
	{
		if(upSpeed <= MAX_SPEED)
		{
			upSpeed += ACCEL * delta;
			downSpeed -= SLOW *  4 * delta;
		}
	}
	@Override
	public void moveDown(float delta)
	{
		if(downSpeed <= MAX_SPEED)
		{
			downSpeed += ACCEL * delta;
			upSpeed -= SLOW * 4 * delta;
		}
	}
	
}
