package com.joec.ld29;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MenuScreen implements Screen
{

	private LudumDare29 game;

	SpriteBatch batch;
	
	int width;
	int height;
	
	int size = 32;
	
	float rotation = 0;
	int rotDirection = 1;
	
	Resources res;
	public MenuScreen(LudumDare29 game)
	{
		this.game = game;
	}
	
	@Override
	public void render(float delta) 
	{
		Gdx.gl20.glClearColor(0, 0, 0, 0);
		Gdx.gl20.glClear(Gdx.gl20.GL_COLOR_BUFFER_BIT);
		
		batch.begin();
		//draw a ton'o backdrop vein pink stuff
		for(int ix = 0; ix <= width; ix += size)
		{
			for(int iy = 0; iy <= height; iy += size)
			{
				batch.draw(res.backdropTexture, ix, iy, size, size);
			}
		}
		//draw a ton 'o skin
		for(int index = 0; index <= width; index += size)
		{
			batch.draw(res.skinTexture, index, 0, size, size);
			batch.draw(res.skinTexture, index, height, 0, 0, size, size, 1, 1, 180, 0, 0, res.skinTexture.getWidth(), res.skinTexture.getHeight(), false, false);
		}
		//draw the logo 
		batch.draw(res.logoTexture, width/2 - 256, height * 3/4, 512, 256);
		//draw the space bar instructions
		if(rotDirection == 1)
		{
			rotation += 60 * delta;
			if(rotation > 40)
				rotDirection = -1;
		}
		else
		{
			rotation -= 60 * delta;
			if(rotation < -40)
				rotDirection = 1;
		}
		drawRotatedTexture(res.spaceBarTexture, width/2 - 128, height * 1/4, 256, 52, rotation);
		//draw some other fun stuff!
		drawRotatedTexture(res.whiteCell1Texture, width / 4, height /2, size * 2, size * 2, rotation);
		drawRotatedTexture(res.redCellTexture, width / 2, height /2, size * 2, size * 2, rotation);
		drawRotatedTexture(res.bacteria1Texture, width * 3/4, height /2, size * 2, size * 2, rotation);
		batch.end();
		
		if(Gdx.input.isKeyPressed(Keys.NUM_1))
		{
			game.goToGameScreen(false);
		}
		if(Gdx.input.isKeyPressed(Keys.NUM_2))
		{
			game.goToGameScreen(true);
		}
	}

	private void drawRotatedTexture(Texture tex, float x, float y, int width, int height, float rotation)
	{
		batch.draw(tex, x, y, width / 2, height / 2, width, height, 1, 1, rotation, 0, 0, tex.getWidth(), tex.getHeight(), false, false);
	}
	
	@Override
	public void resize(int width, int height) 
	{
		this.width = width;
		this.height = height;
		
	}

	@Override
	public void show() 
	{
		batch = new SpriteBatch();
		res = new Resources();
	}

	@Override
	public void hide() {}

	@Override
	public void pause() {}

	@Override
	public void resume() {}

	@Override
	public void dispose() 
	{
		
	}

}
