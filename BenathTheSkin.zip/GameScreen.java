package com.joec.ld29;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.joec.ld29.Antibodies.Antibody;

public class GameScreen implements Screen
{

	private LudumDare29 game;
	
	GameManager gm;
	SpriteBatch batch;
	Resources res;

	int width;
	int height;
	
	int size = 32;
	
	boolean shootKeyReset = true;
	boolean secondShootKeyReset = true;
	
	boolean multiplayer;
	public GameScreen(LudumDare29 game)
	{
		this.game = game;
	}
	
	@Override
	public void render(float delta) 
	{
		Gdx.gl20.glClearColor(0, 0, 0, 0);
		Gdx.gl20.glClear(Gdx.gl20.GL_COLOR_BUFFER_BIT);
		
		//keyboard input
		getInput(delta);
		if(!gm.gameEnded)
			gm.update(delta);
		
		if(gm.gameEnded && System.currentTimeMillis() > gm.gameEndTime + 4000)
		{
			game.goToMenuScreen();
		}
		batch.begin();
		//draw a ton'o backdrop vein pink stuff
		for(int ix = 0; ix <= width; ix += size)
		{
			for(int iy = 0; iy <= height; iy += size)
			{
				batch.draw(res.backdropTexture, ix, iy, size, size);
			}
		}
		//draw a ton 'o skin
		for(int index = 0; index <= width; index += size)
		{
			batch.draw(res.skinTexture, index, 0, size, size);
			batch.draw(res.skinTexture, index, height, 0, 0, size, size, 1, 1, 180, 0, 0, res.skinTexture.getWidth(), res.skinTexture.getHeight(), false, false);
		}
		//draw the bacteria cells
		for(AutoCell ac : gm.bacteriaCells)
		{
			if(ac.alive)
				drawRotatedTexture(res.bacteria1Texture, ac.getX(), ac.getY(), size, size, ac.rotation);
			else
				drawRotatedTexture(res.deadBacteriaTexture, ac.getX(), ac.getY(), size, size, ac.rotation);
		}
		//draw the red blood cells
		for(AutoCell ac : gm.redBloodCells)
		{
			if(ac.alive)
				drawRotatedTexture(res.redCellTexture, ac.getX(), ac.getY(), size, size, ac.rotation);
			else
				drawRotatedTexture(res.deadRedCellTexture, ac.getX(), ac.getY(), size, size, ac.rotation);
		}
		//draw antibodies
		for(Antibody ant : gm.antibodies.antibodyList)
		{
			drawRotatedTexture(res.antibodyTexture, ant.colShape.positionX, ant.colShape.positionY, size, size, ant.angle);	
		}
		//draw the white blood cell
		drawRotatedTexture(res.whiteCell1Texture, gm.whiteCell.getX(), gm.whiteCell.getY(), size, size, gm.whiteCell.rotation);
		//draw the arrow
		drawRotatedTexture(res.arrowTexture, gm.whiteCell.getX() - 32, gm.whiteCell.getY() - 32, 96, 96, gm.arrowAngle);
		//now draw the second white cell
		if(multiplayer)
		{
			drawRotatedTexture(res.whiteCell1Texture, gm.secondWhiteCell.getX(), gm.secondWhiteCell.getY(), size, size, gm.secondWhiteCell.rotation);
			//draw the second arrow
			drawRotatedTexture(res.arrowTexture, gm.secondWhiteCell.getX() - 32, gm.secondWhiteCell.getY() - 32, 96, 96, gm.secondArrowAngle);
		}
		//draw the BIG BOSS!
		if(gm.boss.alive)
			drawRotatedTexture(res.bigBacteriaTexture, gm.boss.getX(), gm.boss.getY(), 128, 128, gm.boss.rotation);
		else
			drawRotatedTexture(res.deadBossTexture, gm.boss.getX(), gm.boss.getY(), 128, 128, gm.boss.rotation);
		//draw the GUI
		//health cross
		batch.draw(res.healthTexture, 25, 25, size / 2, size / 2);
		//health bar
		for(int index = 0; index < gm.health * 10; index += 10)
		{
			batch.draw(res.healthBarTexture, index + 60, 27, 10, 10);
		}
		//antibody bar
		batch.draw(res.antibodyTexture, 25, 45, size / 2, size / 2);
		for(int index = 0; index < gm.antibodyShots * 10; index += 10)
		{
			batch.draw(res.antibodyBarTexture, index + 60, 47, 10, 10);
		}
		//BOSS BAR!!!
		if(gm.boss.spawned)
		{
			batch.draw(res.bigBacteriaTexture, 25, height - 25, 16, 16);
			for(int index = 0; index < gm.boss.health * 5; index += 10)
			{
				batch.draw(res.bossBarTexture, index + 60, height - 23, 10, 10);
			}
		}
		//win texture
		if(!gm.boss.alive)
			batch.draw(res.winTexture, width/2 - 128, height/2 - 64, 256, 128);
		//lose texture
		if(gm.health <= 0)
			batch.draw(res.loseTexture, width/2 - 128, height/2 - 64, 256, 128);
		batch.end();
	}

	private void drawRotatedTexture(Texture tex, float x, float y, int width, int height, float rotation)
	{
		batch.draw(tex, x, y, width / 2, height / 2, width, height, 1, 1, rotation, 0, 0, tex.getWidth(), tex.getHeight(), false, false);
	}
	
	private void getInput(float delta) 
	{
		//first player controls
		if(Gdx.input.isKeyPressed(Keys.LEFT))
			gm.whiteCell.moveLeft(delta);
		if(Gdx.input.isKeyPressed(Keys.RIGHT))
			gm.whiteCell.moveRight(delta);
		if(Gdx.input.isKeyPressed(Keys.UP))
			gm.whiteCell.moveUp(delta);
		if(Gdx.input.isKeyPressed(Keys.DOWN))
			gm.whiteCell.moveDown(delta);
		if(Gdx.input.isKeyPressed(Keys.NUMPAD_1))
			gm.rotateArrow(1, delta);
		if(Gdx.input.isKeyPressed(Keys.NUMPAD_3))
			gm.rotateArrow(-1, delta);
		if(Gdx.input.isKeyPressed(Keys.NUMPAD_2) && shootKeyReset)
		{
			gm.shoot();
			shootKeyReset = false;
		}
		if(!Gdx.input.isKeyPressed(Keys.NUMPAD_2))
			shootKeyReset = true;
		//second player controls
		if(multiplayer)
		{
			if(Gdx.input.isKeyPressed(Keys.A))
				gm.secondWhiteCell.moveLeft(delta);
			if(Gdx.input.isKeyPressed(Keys.D))
				gm.secondWhiteCell.moveRight(delta);
			if(Gdx.input.isKeyPressed(Keys.W))
				gm.secondWhiteCell.moveUp(delta);
			if(Gdx.input.isKeyPressed(Keys.S))
				gm.secondWhiteCell.moveDown(delta);
			if(Gdx.input.isKeyPressed(Keys.J))
				gm.secondRotateArrow(1, delta);
			if(Gdx.input.isKeyPressed(Keys.L))
				gm.secondRotateArrow(-1, delta);
			if(Gdx.input.isKeyPressed(Keys.K) && secondShootKeyReset)
			{
				gm.secondPlayerShoot();
				secondShootKeyReset = false;
			}
			if(!Gdx.input.isKeyPressed(Keys.K))
				secondShootKeyReset = true;
		}
		
		
	}

	@Override
	public void resize(int width, int height) 
	{
		this.width = width;
		this.height = height;
		
		gm = new GameManager(size, width, height, multiplayer);
	}

	@Override
	public void show() 
	{
		batch = new SpriteBatch();
		res = new Resources();
	}

	@Override
	public void hide() {}

	@Override
	public void pause() {}

	@Override
	public void resume() {}

	@Override
	public void dispose() 
	{
		
	}

}
