package com.joec.ld29;

import com.badlogic.gdx.graphics.Texture;

public class Resources 
{
	public Texture skinTexture;
	public Texture backdropTexture;
	public Texture whiteCell1Texture;
	public Texture redCellTexture;
	public Texture bacteria1Texture;
	public Texture deadBacteriaTexture;
	public Texture deadRedCellTexture;
	public Texture healthTexture;
	public Texture healthBarTexture;
	public Texture antibodyTexture;
	public Texture arrowTexture;
	public Texture antibodyBarTexture;
	public Texture logoTexture;
	public Texture spaceBarTexture;
	public Texture bigBacteriaTexture;
	public Texture deadBossTexture;
	public Texture winTexture;
	public Texture loseTexture;
	public Texture bossBarTexture;
	
	public Resources()
	{
		skinTexture = new Texture("skin.png");
		backdropTexture = new Texture("backdrop.png");
		whiteCell1Texture = new Texture("whiteCell1.png");
		redCellTexture = new Texture("redBloodCell.png");
		bacteria1Texture = new Texture("bacteria1.png");
		deadBacteriaTexture = new Texture("deadCell.png");
		deadRedCellTexture = new Texture("deadRedCell.png");
		healthTexture = new Texture("health.png");
		healthBarTexture = new Texture("healthBar.png");
		antibodyTexture = new Texture("antibody.png");
		arrowTexture = new Texture("arrow.png");
		antibodyBarTexture = new Texture("antibodyBar.png");
		logoTexture = new Texture("logo.png");
		spaceBarTexture = new Texture("pressSpace.png");
		bigBacteriaTexture = new Texture("bigBacteria.png");
		deadBossTexture = new Texture("deadBoss.png");
		winTexture = new Texture("youWin.png");
		loseTexture = new Texture("gameover.png");
		bossBarTexture = new Texture("bossBar.png");
	}
}
