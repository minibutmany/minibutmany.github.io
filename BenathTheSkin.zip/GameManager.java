package com.joec.ld29;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.joec.ld29.Antibodies.Antibody;

public class GameManager 
{
	Cell whiteCell;
	Cell secondWhiteCell;
	BossBacteria boss;
	Antibodies antibodies;
	ArrayList<AutoCell> redBloodCells;
	ArrayList<BacteriaCell> bacteriaCells;
	
	CollisionShape leftWall;
	CollisionShape rightWall;
	CollisionShape topWall;
	CollisionShape bottomWall;
	
	CollisionShape bossLeftWall;
	CollisionShape bossRightWall;
	CollisionShape bossTopWall;
	CollisionShape bossBottomWall;
	long lastSpawnTime = 0;
	int spawnTime = 2000;
	
	Random rand = new Random();
	
	int size;
	int width;
	int height;
	
	int health;
	int antibodyShots;
	
	float arrowAngle = 90;
	float secondArrowAngle = 90;
	
	long startTime = 0;
	
	long gameEndTime;
	
	boolean gameEnded = false;
	
	boolean multiplayer = false;
	
	long lastHitTime = 0;
	
	private static final long HIT_INTERVAL = 1000;
	private static final float ARROW_ROT = 300;
	private static final float BOSS_TIME = 60000;
	
	Sound smash;
	Sound bop;
	Sound blip;
	
	public GameManager(int size, int width, int height, boolean multiplayer)
	{
		this.multiplayer = multiplayer;
		whiteCell = new Cell(size);
		secondWhiteCell = new Cell(size, 300, 120);
		if(!multiplayer)
		{
			secondWhiteCell.shape.positionX = -64;
			secondWhiteCell.shape.positionY = -64;
		}
		redBloodCells = new ArrayList<AutoCell>();
		bacteriaCells = new ArrayList<BacteriaCell>();
		
		leftWall = new CollisionShape(-5, 0, 5, height);
		rightWall = new CollisionShape(width, 0, 5, height);
		topWall = new CollisionShape(0, height - size, width, size);
		bottomWall = new CollisionShape(0, 0, width, size);
		
		bossLeftWall = new CollisionShape(-256, 0, 5, height);
		bossRightWall = new CollisionShape(width + 256, 0, 5, height);
		bossTopWall = new CollisionShape(-256, height - size, width + 512, size);
		bossBottomWall = new CollisionShape(-256, 0, width + 512, size);
		
		antibodies = new Antibodies(width, height);

		this.size = size;
		this.width = width;
		this.height = height;
		
		health = 30;
		antibodyShots = 10;
		
		boss = new BossBacteria(size);
		
		smash = Gdx.audio.newSound(Gdx.files.internal("smash.mp3"));
		bop = Gdx.audio.newSound(Gdx.files.internal("bop.mp3"));
		blip = Gdx.audio.newSound(Gdx.files.internal("blip.mp3"));
		
		startTime = System.currentTimeMillis();
	}
	
	public void update(float delta)
	{
		updateLevel();
		antibodies.update(delta);
		//update white cell
		whiteCell.update(delta);
		if(multiplayer)
			secondWhiteCell.update(delta);
		//check collision with walls
		whiteCell.shape.resetCollision();
		whiteCell.shape.checkCollision(leftWall);
		whiteCell.shape.checkCollision(rightWall);
		whiteCell.shape.checkCollision(topWall);
		whiteCell.shape.checkCollision(bottomWall);
		if(multiplayer)
		{
			secondWhiteCell.shape.resetCollision();
			secondWhiteCell.shape.checkCollision(leftWall);
			secondWhiteCell.shape.checkCollision(rightWall);
			secondWhiteCell.shape.checkCollision(topWall);
			secondWhiteCell.shape.checkCollision(bottomWall);
			
			secondWhiteCell.shape.checkCollision(whiteCell.shape);
			whiteCell.shape.checkCollision(secondWhiteCell.shape);	
		}


		//update boss
		boss.update(delta, whiteCell.getX(), whiteCell.getY());
		boss.shape.resetCollision();
		boss.shape.checkCollision(bossLeftWall);
		boss.shape.checkCollision(bossRightWall);
		boss.shape.checkCollision(bossTopWall);
		boss.shape.checkCollision(bossBottomWall);
		//check collision with boss
		if((whiteCell.shape.rectanglesColliding(boss.shape) 
				|| (secondWhiteCell.shape.rectanglesColliding(boss.shape) && multiplayer)) 
				&& boss.alive
				&& System.currentTimeMillis() > lastHitTime + HIT_INTERVAL)
		{
			health -= 10;
			lastHitTime = System.currentTimeMillis();
		}
		//check antibodies with boss
		Iterator<Antibody> antIt = antibodies.antibodyList.iterator();
		while(antIt.hasNext())
		{
			if(boss.killOnCollisionWith(antIt.next().colShape))
			{
				health += 1;
				antibodyShots += 1;
				antIt.remove();
			}
		}
		//update red cell
		for(AutoCell ac : redBloodCells)
		{
			if(ac.alive)
			{
				ac.update(delta);
				ac.shape.resetCollision();
				
				ac.shape.checkCollision(whiteCell.shape);
				whiteCell.shape.checkCollision(ac.shape);
				
				if(multiplayer)
				{
					ac.shape.checkCollision(secondWhiteCell.shape);
					secondWhiteCell.shape.checkCollision(ac.shape);
				}
			}
		}
		//update bacteria cell
		for(BacteriaCell bc : bacteriaCells)
		{
			if(bc.alive)
			{
				bc.update(delta);
				//kill on collision with player 1
				if(bc.killOnCollisionWith(whiteCell.shape))
				{
					health += 1;
					antibodyShots += 1;
					long id = bop.play();
					bop.setPitch(id, 2);
				}
				//kill on collision with player 2
				if(bc.killOnCollisionWith(secondWhiteCell.shape) && multiplayer)
				{
					health += 1;
					antibodyShots += 1;
					long id = bop.play();
					bop.setPitch(id, 2);
				}
				//kill red blood cells
				for(AutoCell ac : redBloodCells)
				{
					if(ac.alive && ac.killOnCollisionWith(bc.shape))
					{
						health -= 2;
						long id = bop.play();
						bop.setPitch(id, 2);
					}
				}
				//kill bacteria with antibodies
				for(Antibody ant : antibodies.antibodyList)
				{
					if(bc.killOnCollisionWith(ant.colShape))
					{
						health += 1;
						antibodyShots += 1;
						smash.play(0.8f);
					}
				}
			}
		}
		//keep health and antibodies at max level
		if(health > 70)
			health = 70;
		if(antibodyShots > 70)
			antibodyShots = 70;
		//spawn something
		if(System.currentTimeMillis() > lastSpawnTime + spawnTime && System.currentTimeMillis() - startTime < BOSS_TIME)
		{
			int randInt = rand.nextInt(4);
			if(randInt <= 2)
				redBloodCells.add(spawnCell(size));
			if(randInt == 3)
				bacteriaCells.add(spawnBacteriaCell(size));
			lastSpawnTime = System.currentTimeMillis();
		}
		//if it has been more than a minute, let out the boss!
		if(System.currentTimeMillis() - startTime > BOSS_TIME && !boss.spawned)
		{
			boss.spawned = true;
			if(rand.nextBoolean())
			{
				boss.shape.positionX = -128;
				boss.shape.positionY = rand.nextInt(height - 128 * 3) + 128;
			}
			else//spawn on right
			{
				boss.shape.positionX = width + 128;
				boss.shape.positionY = rand.nextInt(height - 128 * 3) + 128;
			}
			//max ammo
			antibodyShots = 70;
		}
		//get rid of dead stuff and off screen stuff
		Iterator<BacteriaCell> itr = bacteriaCells.iterator();
		while(itr.hasNext())
		{
			BacteriaCell bc = itr.next();
			//check for dead too long
			if(!bc.alive && System.currentTimeMillis() > bc.killTime + bc.DEAD_TIME)
			{
				itr.remove();
			}
			//check for offscreen
			if((bc.moveDirectionX == 1 && bc.getX() > width + size) || (bc.moveDirectionX == -1 && bc.getX() < -size))
			{
				itr.remove();
			}
		}
		Iterator<AutoCell> aitr = redBloodCells.iterator();
		while(aitr.hasNext())
		{
			AutoCell ac = aitr.next();
			// check for dead too long
			if(!ac.alive && System.currentTimeMillis() > ac.killTime + ac.DEAD_TIME)
			{
				aitr.remove();
			}
			//check for offscreen
			if((ac.moveDirectionX == 1 && ac.getX() > width + size) || (ac.moveDirectionX == -1 && ac.getX() < -size))
			{
				aitr.remove();
			}
		}
		if(health <= 0 || !boss.alive)
		{
			gameEndTime = System.currentTimeMillis();
			gameEnded = true;
		}
	}
	
	private void updateLevel()
	{
		long timeDiff = System.currentTimeMillis() - startTime;
		if(timeDiff > 10000)
			spawnTime = 750;
		if(timeDiff > 20000)
			spawnTime = 550;
		if(timeDiff > 25000)
			spawnTime = 400;
		if(timeDiff > 35000)
			spawnTime = 325;
		if(timeDiff > 55000)
			spawnTime = 325;	
			
	}
	
	private AutoCell spawnCell(int size)
	{
		AutoCell newCell = new AutoCell(size);
		//spawn on left
		if(rand.nextBoolean())
		{
			newCell.shape.positionX = -size;
			newCell.moveDirectionX = 1;
		}
		else//spawn on right
		{
			newCell.shape.positionX = width + size;
			newCell.moveDirectionX = -1;
		}
		newCell.shape.positionY = rand.nextInt(height - size * 3) + size;
		return newCell;
	}
	
	private BacteriaCell spawnBacteriaCell(int size)
	{
		BacteriaCell newCell = new BacteriaCell(size);
		newCell.alive = true;
		//spawn on left
		if(rand.nextBoolean())
		{
			newCell.shape.positionX = -size;
			newCell.moveDirectionX = 1;
		}
		else//spawn on right
		{
			newCell.shape.positionX = width + size;
			newCell.moveDirectionX = -1;
		}
		newCell.shape.positionY = rand.nextInt(height - size * 3) + size;
		return newCell;
	}
	
	public void rotateArrow(int direction, float delta)
	{
		arrowAngle += direction * delta * ARROW_ROT;
		if(arrowAngle > 360)
			arrowAngle = arrowAngle - 360;
		if(arrowAngle < 0)
			arrowAngle = 360 - arrowAngle;
	}
	
	public void secondRotateArrow(int direction, float delta)
	{
		secondArrowAngle += direction * delta * ARROW_ROT;
		if(secondArrowAngle > 360)
			secondArrowAngle = secondArrowAngle - 360;
		if(secondArrowAngle < 0)
			secondArrowAngle = 360 - secondArrowAngle;
	}
	public void shoot()
	{
		blip.play();
		if(antibodyShots > 0)
		{
			antibodies.shoot(whiteCell.getX(), whiteCell.getY(), arrowAngle);
			antibodyShots -= 1;
		}
	}
	
	public void secondPlayerShoot()
	{
		blip.play();
		if(antibodyShots > 0)
		{
			antibodies.shoot(secondWhiteCell.getX(), secondWhiteCell.getY(), secondArrowAngle);
			antibodyShots -= 1;
		}
	}
}
