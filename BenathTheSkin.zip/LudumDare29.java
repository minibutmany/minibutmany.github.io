package com.joec.ld29;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;

public class LudumDare29 extends Game 
{
	GameScreen gameScreen;
	MenuScreen menuScreen;
	Music music;
	@Override
	public void create() 
	{
		music = Gdx.audio.newMusic(Gdx.files.internal("music.mp3"));
		music.setLooping(true);
		music.setVolume(0.7f);
		menuScreen = new MenuScreen(this);
		gameScreen = new GameScreen(this);
		goToMenuScreen();
		music.play();
	}
	
	public void goToMenuScreen()
	{
		setScreen(menuScreen);
	}
	
	public void goToGameScreen(boolean multiplayer)
	{
		gameScreen.multiplayer = multiplayer;
		setScreen(gameScreen);
	}
    @Override
    public void dispose() {
            super.dispose();
    }
    @Override
    public void render() {   
            super.render();
    }
    @Override
    public void resize(int width, int height) {
            super.resize(width, height);
    }
    @Override
    public void pause() {
            super.pause();
    }
    @Override
    public void resume() {
            super.resume();
    }
}
