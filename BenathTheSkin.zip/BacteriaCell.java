package com.joec.ld29;

public class BacteriaCell extends AutoCell
{

	public BacteriaCell(int size) 
	{
		super(size);
	}
	
	public BacteriaCell(int size, float x, float y) 
	{
		super(size, x, y);
	}
	
	@Override
	public void update(float delta)
	{
		if(alive)
		{
			if(moveDirectionX == 1)
				moveRight(delta);
			if(moveDirectionX == -1)
				moveLeft(delta);
		}
		//move character
		shape.moveLeft(delta, leftSpeed);
		shape.moveRight(delta, rightSpeed);
		shape.moveUp(delta, upSpeed);
		shape.moveDown(delta, downSpeed);
		//slow down
		if(leftSpeed > 0)
			leftSpeed -= SLOW * delta;
		if(rightSpeed > 0)
			rightSpeed -= SLOW * delta;
		if(upSpeed > 0)
			upSpeed -= SLOW * delta;
		if(downSpeed > 0)
			downSpeed -= SLOW * delta;
	}

}
