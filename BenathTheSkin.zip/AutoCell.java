package com.joec.ld29;

public class AutoCell extends Cell
{

	int moveDirectionX = 0;
	
	public AutoCell(int size) 
	{
		super(size);
		MAX_SPEED = 50;
		ACCEL = 70;
		SLOW = 70;
	}
	
	public AutoCell(int size, float x, float y)
	{
		super(size, x, y);
		MAX_SPEED = 70;
		ACCEL = 70;
		SLOW = 70;
	}
	
	@Override
	public void update(float delta)
	{
		if(alive)
		{
			if(moveDirectionX == 1)
				moveRight(delta);
			if(moveDirectionX == -1)
				moveLeft(delta);
		}
		super.update(delta);
	}

	public boolean killOnCollisionWith(CollisionShape objShape) 
	{
		if(shape.rectanglesColliding(objShape))
		{
			kill();
			return true;
		}
		else
			return false;
	}
}
