package com.joec.ld29;

import java.util.ArrayList;
import java.util.Iterator;

public class Antibodies 
{
	ArrayList<Antibody> antibodyList;
	int size = 32;
	int width;
	int height;
	
	public Antibodies(int width, int height)
	{
		 antibodyList = new ArrayList<Antibody>();
		 this.width = width;
		 this.height = height;
	}
	
	public void shoot(float x, float y, float angle)
	{
		antibodyList.add(new Antibody(x, y, angle));
	}
	
	public void update(float delta)
	{
		Iterator<Antibody> itr = antibodyList.iterator();
		while(itr.hasNext())
		{
			Antibody ant = itr.next();
			//move along now!
			ant.advance(delta);
			//get rid of the off screen anti-bodies
			//RESPECT THE RAM! RESPECT IT!
			if(ant.colShape.positionX < -size || ant.colShape.positionY < -size || ant.colShape.positionX > width || ant.colShape.positionY > height)
			{
				itr.remove();
			}
		}
	}
	
	public class Antibody
	{
		CollisionShape colShape;
		float angle;
		private static final float SPEED = 475;
		public Antibody(float x, float y, float angle)
		{
			colShape = new CollisionShape(x, y, size, size);
			this.angle = angle;
		}
		
		public void advance(float delta)
		{
			colShape.positionX += Math.cos(Math.toRadians(angle + 90)) * SPEED * delta;
			colShape.positionY += Math.sin(Math.toRadians(angle + 90)) * SPEED * delta;
		}
	}
}
