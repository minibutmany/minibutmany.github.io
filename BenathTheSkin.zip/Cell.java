package com.joec.ld29;

public class Cell 
{
	CollisionShape shape;
	
	float leftSpeed = 0;
	float rightSpeed = 0;
	float upSpeed = 0;
	float downSpeed = 0;
	
	float rotation = 0;
	
	protected float MAX_SPEED = 180;
	protected float ACCEL = 140;
	protected float SLOW = 160;
	protected float RAND_SPEED = 80;
	
	public long killTime = 0;
	public static int DEAD_TIME = 8000;
	
	boolean alive;
	public Cell(int size)
	{
		shape = new CollisionShape(128, 128, size, size);
		alive = true;
	}
	
	public Cell(int size, float x, float y)
	{
		shape = new CollisionShape(x, y, size, size);
		alive = true;
	}
	
	
	public void update(float delta)
	{
		//bounce off the walls!
		if(shape.distanceLeft <= 5)
		{
			leftSpeed = 0;
			rightSpeed = (float) (Math.random()*RAND_SPEED) + RAND_SPEED / 4;
		}
		if(shape.distanceRight <= 5)
		{
			rightSpeed = 0;
			leftSpeed = (float) (Math.random()*RAND_SPEED)  + RAND_SPEED / 4;
		}
		if(shape.distanceTop <= 5)
		{
			upSpeed = 0;
			downSpeed = (float) (Math.random()*RAND_SPEED)  + RAND_SPEED / 4;
		}
		if(shape.distanceBottom <= 5)
		{
			downSpeed = 0;
			upSpeed = (float) (Math.random()*RAND_SPEED)  + RAND_SPEED / 4;
		}
		//move character
		shape.moveLeft(delta, leftSpeed);
		shape.moveRight(delta, rightSpeed);
		shape.moveUp(delta, upSpeed);
		shape.moveDown(delta, downSpeed);
		//slow down
		if(leftSpeed > 0)
			leftSpeed -= SLOW/2 * delta;
		if(rightSpeed > 0)
			rightSpeed -= SLOW/2 * delta;
		if(upSpeed > 0)
			upSpeed -= SLOW/2 * delta;
		if(downSpeed > 0)
			downSpeed -= SLOW/2 * delta;
	}
	
	public void moveLeft(float delta)
	{
		if(leftSpeed <= MAX_SPEED)
		{
			leftSpeed += ACCEL * delta;
			rightSpeed -= SLOW * delta;
		}
		rotate(1);
	}
	public void moveRight(float delta)
	{
		if(rightSpeed <= MAX_SPEED)
		{
			rightSpeed += ACCEL * delta;
			leftSpeed -= SLOW * delta;
		}
		rotate(-1);
	}
	public void moveUp(float delta)
	{
		if(upSpeed <= MAX_SPEED)
		{
			upSpeed += ACCEL * delta;
			downSpeed -= SLOW * delta;
		}
	}
	public void moveDown(float delta)
	{
		if(downSpeed <= MAX_SPEED)
		{
			downSpeed += ACCEL * delta;
			upSpeed -= SLOW * delta;
		}
	}
	
	public float getX()
	{
		return shape.positionX;
	}
	
	public float getY()
	{
		return shape.positionY;
	}
	
	public void rotate(int direction)
	{
		rotation += 0.5 * direction;
		if(rotation > 360)
		{
			rotation = 360 - rotation;
		}
	}
	
	protected void kill()
	{
		alive = false;
		killTime = System.currentTimeMillis();
	}
}
